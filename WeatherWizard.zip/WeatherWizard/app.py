import os
import logging
import requests
import re
import json
import googlemaps
from flask import Flask, render_template, request, jsonify

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET")

# API constants
WEATHER_API_KEY = os.environ.get("WEATHER_API_KEY", "test_key")
WEATHER_API_URL = "http://api.weatherapi.com/v1/current.json"
GOOGLE_MAPS_API_KEY = os.environ.get("GOOGLE_MAPS_API_KEY")

# Initialize Google Maps client
gmaps = None
if GOOGLE_MAPS_API_KEY:
    gmaps = googlemaps.Client(key=GOOGLE_MAPS_API_KEY)
    logging.info("Google Maps API client initialized successfully")
else:
    logging.warning("GOOGLE_MAPS_API_KEY not provided, PIN code validation will use local database only")

# Indian PIN code validation
# The PIN code pattern in India follows specific ranges for different regions
VALID_PIN_RANGES = {
    # Delhi
    '11': (110000, 110999),
    # Uttar Pradesh
    '20': (200000, 209999), '21': (210000, 219999), '22': (220000, 229999), '23': (230000, 239999), 
    '24': (240000, 249999), '25': (250000, 259999), '26': (260000, 269999), '27': (270000, 279999),
    '28': (280000, 289999),
    # Maharashtra (including Mumbai)
    '40': (400000, 409999), '41': (410000, 419999), '42': (420000, 429999), '43': (430000, 439999),
    '44': (440000, 449999),
    # Tamil Nadu (including Chennai)
    '60': (600000, 609999), '61': (610000, 619999), '62': (620000, 629999), '63': (630000, 639999),
    # Karnataka (including Bangalore)
    '56': (560000, 569999), '57': (570000, 579999), '58': (580000, 589999),
    # Andhra Pradesh & Telangana (including Hyderabad)
    '50': (500000, 509999), '51': (510000, 519999), '52': (520000, 529999), '53': (530000, 539999),
    # West Bengal (including Kolkata)
    '70': (700000, 709999), '71': (710000, 719999), '72': (720000, 729999), '73': (730000, 739999),
    # Bihar & Jharkhand
    '80': (800000, 809999), '81': (810000, 819999), '82': (820000, 829999), '83': (830000, 839999),
    # Gujarat
    '36': (360000, 369999), '37': (370000, 379999), '38': (380000, 389999), '39': (390000, 399999),
    # Rajasthan
    '30': (300000, 309999), '31': (310000, 319999), '32': (320000, 329999), '33': (330000, 339999),
    '34': (340000, 349999),
    # Punjab & Haryana
    '14': (140000, 149999), '15': (150000, 159999), '16': (160000, 169999),
    # Kerala
    '67': (670000, 679999), '68': (680000, 689999), '69': (690000, 699999),
    # Assam & Northeast
    '78': (780000, 789999), '79': (790000, 799999),
}

def is_valid_indian_pin(pin_code):
    """
    Validate if a PIN code is a valid Indian PIN code based on known ranges 
    and verify it using Google Maps Geocoding API if available.
    
    Returns:
    - If invalid: (False, error_message)
    - If valid: (True, None) or (True, location_info)
    """
    # Basic validation
    if not pin_code.isdigit() or len(pin_code) != 6:
        return False, "PIN code must be a 6-digit number"
    
    # Check first two digits against our ranges
    prefix = pin_code[:2]
    if prefix not in VALID_PIN_RANGES:
        return False, f"PIN code prefix '{prefix}' is not a valid Indian postal code region"
    
    pin_num = int(pin_code)
    min_range, max_range = VALID_PIN_RANGES[prefix]
    if not (min_range <= pin_num <= max_range):
        return False, f"PIN code {pin_code} is outside the valid range for region '{prefix}'"
    
    # If Google Maps client is available, verify the PIN code exists
    if gmaps:
        try:
            # Use Google Maps Geocoding API to verify this is a real PIN code
            geocode_result = gmaps.geocode(f"{pin_code}, India", region="in")
            
            # If we got results, check if any of them are in India
            if geocode_result:
                # Extract the first result and check country
                for component in geocode_result[0]['address_components']:
                    if 'country' in component['types'] and component['short_name'] == 'IN':
                        # This is a valid Indian PIN code - return location info
                        location_name = geocode_result[0]['formatted_address']
                        lat = geocode_result[0]['geometry']['location']['lat']
                        lng = geocode_result[0]['geometry']['location']['lng']
                        logging.info(f"Verified PIN code {pin_code}: {location_name} ({lat},{lng})")
                        
                        # Return location info that can be used directly
                        return True, {
                            "address": location_name,
                            "lat": lat,
                            "lng": lng
                        }
                
                # If we got here, the location is not in India
                return False, f"PIN code {pin_code} does not appear to be in India"
            else:
                # No results found for this PIN code
                return False, f"PIN code {pin_code} could not be verified as a valid location"
                
        except Exception as e:
            # Log the error but fall back to our basic validation
            logging.error(f"Error verifying PIN code with Google Maps: {str(e)}")
    
    # If we got here, either the Google Maps API is not available or we encountered an error
    # Fall back to our basic validation which has already passed
    return True, None

@app.route("/")
def index():
    """Render the main page."""
    return render_template("index.html")

@app.route("/get_weather", methods=["POST"])
def get_weather():
    """Get weather data for the requested city or postal code."""
    city = request.form.get("city")
    lat = request.form.get("lat")
    lon = request.form.get("lon")
    
    if not city and not (lat and lon):
        return jsonify({"error": "Please provide either a location name or coordinates."}), 400
    
    try:
        # Make request to Weather API
        params = {
            "key": WEATHER_API_KEY
        }
        
        # Use coordinates if provided, otherwise use city name or postal code
        if lat and lon:
            params["q"] = f"{lat},{lon}"
        else:
            # Try to detect if input is an Indian PIN code (6 digits)
            if city.strip().isdigit() and len(city.strip()) == 6:
                pin_code = city.strip()
                
                # Validate the PIN code using our improved validation
                is_valid, validation_result = is_valid_indian_pin(pin_code)
                
                if is_valid:
                    # This is a valid Indian PIN
                    if validation_result and isinstance(validation_result, dict):
                        # We have detailed location information from Google Maps
                        logging.info(f"Using coordinates for PIN {pin_code}: {validation_result['lat']},{validation_result['lng']}")
                        
                        # Use the exact coordinates for more accuracy
                        params["q"] = f"{validation_result['lat']},{validation_result['lng']}"
                    else:
                        # We only have basic validation, use the PIN with country
                        params["q"] = f"{pin_code}, India"
                        logging.debug(f"Valid Indian PIN code detected: {pin_code}")
                else:
                    # Invalid PIN code - return the specific error message
                    return jsonify({
                        "error": f"Invalid Indian PIN code: {validation_result}"
                    }), 400
            else:
                # For all other inputs, use as is (city names)
                params["q"] = city
        
        logging.debug(f"Weather API query: {params}")
        response = requests.get(WEATHER_API_URL, params=params)
        
        # Check if request was successful
        if response.status_code == 200:
            weather_data = response.json()
            
            # Extract relevant data
            result = {
                "location": {
                    "name": weather_data["location"]["name"],
                    "country": weather_data["location"]["country"],
                    "localtime": weather_data["location"]["localtime"]
                },
                "current": {
                    "temp_c": weather_data["current"]["temp_c"],
                    "condition": {
                        "text": weather_data["current"]["condition"]["text"],
                        "icon": weather_data["current"]["condition"]["icon"]
                    },
                    "humidity": weather_data["current"]["humidity"],
                    "wind_kph": weather_data["current"]["wind_kph"]
                }
            }
            
            return jsonify(result)
        
        # Handle API errors
        elif response.status_code == 400:
            return jsonify({"error": "Invalid location data. Please try a different city name or postal code."}), 400
        else:
            logging.error(f"Weather API error: {response.status_code} - {response.text}")
            return jsonify({"error": "Failed to fetch weather data. Please try again later."}), 500
    
    except requests.exceptions.RequestException as e:
        logging.error(f"Request error: {str(e)}")
        return jsonify({"error": "Failed to connect to weather service. Please try again later."}), 500
    
    except Exception as e:
        logging.error(f"Unexpected error: {str(e)}")
        return jsonify({"error": "An unexpected error occurred. Please try again."}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
