document.addEventListener('DOMContentLoaded', function() {
    // Get DOM elements
    const weatherForm = document.getElementById('weatherForm');
    const cityInput = document.getElementById('cityInput');
    const trackButton = document.getElementById('trackButton');
    const loadingIndicator = document.getElementById('loadingIndicator');
    const errorMessage = document.getElementById('errorMessage');
    const errorText = document.getElementById('errorText');
    const weatherResults = document.getElementById('weatherResults');
    
    // Satellite tracking overlay elements
    const satelliteOverlay = document.getElementById('satelliteTrackingOverlay');
    const trackingTarget = document.getElementById('trackingTarget');
    const trackingCoords = document.getElementById('trackingCoords');
    const signalStrength = document.getElementById('signalStrength');
    const satelliteStatus = document.getElementById('satelliteStatus');
    const trackingProgress = document.getElementById('trackingProgress');
    const progressPercentage = document.getElementById('progressPercentage');
    const messageLog = document.getElementById('messageLog');

    // Weather data elements
    const cityName = document.getElementById('cityName');
    const countryName = document.getElementById('countryName');
    const localTimeValue = document.getElementById('localTimeValue');
    const weatherIcon = document.getElementById('weatherIcon');
    const weatherCondition = document.getElementById('weatherCondition');
    const temperature = document.getElementById('temperature');
    const humidity = document.getElementById('humidity');
    const windSpeed = document.getElementById('windSpeed');

    // Auto-detect location on page load
    autoDetectLocation();
    
    // Function to auto-detect user location
    function autoDetectLocation() {
        if (navigator.geolocation) {
            // Show loading while getting location
            showLoading(true);
            
            // Add status message to loading indicator
            document.querySelector('.loading-text').textContent = 'ACQUIRING GEOLOCATION';
            
            navigator.geolocation.getCurrentPosition(
                // Success callback
                function(position) {
                    console.log("Location detected:", position.coords.latitude, position.coords.longitude);
                    document.querySelector('.loading-text').textContent = 'CONNECTING TO SATELLITES';
                    
                    // Create form data with coordinates
                    const formData = new FormData();
                    formData.append('lat', position.coords.latitude);
                    formData.append('lon', position.coords.longitude);
                    
                    // Fetch weather for detected location
                    fetchWeatherData(formData);
                },
                // Error callback
                function(error) {
                    console.error("Geolocation error:", error);
                    showLoading(false);
                    
                    // Show a subtle notification about location access
                    const geoMessage = document.createElement('div');
                    geoMessage.className = 'text-xs text-center text-cyber-pink mt-2 mb-4';
                    geoMessage.innerHTML = '[GEOLOCATION UNAVAILABLE - MANUAL INPUT REQUIRED]';
                    weatherForm.parentNode.insertBefore(geoMessage, weatherForm);
                    
                    // Focus on the city input
                    setTimeout(() => cityInput.focus(), 500);
                },
                // Options
                {
                    timeout: 10000,
                    maximumAge: 0
                }
            );
        } else {
            console.log("Geolocation not supported");
        }
    }

    // Form submission
    weatherForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const inputValue = cityInput.value.trim();
        
        // Validate input
        if (!inputValue) {
            showError('Please enter a city name or Indian PIN code');
            return;
        }
        
        // Validate Indian PIN code format if it looks like a PIN code
        if (/^\d+$/.test(inputValue) && inputValue.length === 6) {
            // Check for valid Indian PIN code format (first digit can't be 0)
            if (inputValue[0] === '0') {
                showError('Invalid Indian PIN code format. Indian PIN codes start with 1-9.');
                return;
            }
            
            // Validate PIN code format using known Indian PIN code patterns
            const validRanges = {
                // Delhi
                '11': true,
                // Maharashtra (including Mumbai)
                '40': true, '41': true, '42': true, '43': true, '44': true,
                // Tamil Nadu (including Chennai)
                '60': true, '61': true, '62': true, '63': true,
                // Karnataka (including Bangalore)
                '56': true, '57': true, '58': true,
                // Andhra Pradesh & Telangana (including Hyderabad)
                '50': true, '51': true, '52': true, '53': true,
                // West Bengal (including Kolkata)
                '70': true, '71': true, '72': true, '73': true,
                // Bihar & Jharkhand
                '80': true, '81': true, '82': true, '83': true,
                // Uttar Pradesh
                '20': true, '21': true, '22': true, '23': true, '24': true, 
                '25': true, '26': true, '27': true, '28': true,
                // Gujarat
                '36': true, '37': true, '38': true, '39': true,
                // Rajasthan
                '30': true, '31': true, '32': true, '33': true, '34': true,
                // Punjab & Haryana
                '14': true, '15': true, '16': true,
                // Kerala
                '67': true, '68': true, '69': true,
                // Assam & Northeast
                '78': true, '79': true,
            };
            
            // Get first two digits of the PIN
            const prefix = inputValue.substring(0, 2);
            
            // If the prefix is not in our valid ranges, show an error
            if (!validRanges[prefix]) {
                showError(`Invalid Indian PIN code format. The prefix "${prefix}" does not match any known Indian PIN code range.`);
                return;
            }
        }

        // Hide any previous results/errors
        hideError();
        hideResults();
        
        // Show satellite tracking animation
        showSatelliteTracking(inputValue);
    });
    
    // Function to show satellite tracking animation
    function showSatelliteTracking(location) {
        // Reset and show satellite tracking overlay
        resetTrackingAnimation();
        satelliteOverlay.classList.remove('hidden');
        
        // Set the target location
        trackingTarget.textContent = location.toUpperCase();
        
        // Simulate satellite tracking process - faster (2 seconds total)
        let progress = 0;
        const totalDuration = 2000; // 2 seconds for the whole animation
        const updateInterval = 50; // Update every 50ms for smoother animation
        const incrementPerStep = 100 / (totalDuration / updateInterval);
        
        // Scientific terminology for messages
        const scientificMessages = [
            "// INITIATING METEOROLOGICAL SCAN SEQUENCE",
            "// TRIANGULATING ATMOSPHERIC DATA NODES",
            "// SYNCHRONIZING WEATHER SATELLITES",
            "// SAMPLING BAROMETRIC PARAMETERS",
            "// ANALYZING PRECIPITATION PROBABILITY",
            "// MAPPING THERMAL GRADIENTS",
            "// CALIBRATING HUMIDITY SENSORS",
            "// CALCULATING WIND VECTOR ANALYSIS"
        ];
        
        // Initial coordinates based on location type
        let targetCoords;
        if (/^\d+$/.test(location) && location.length === 6) {
            // If input is a 6-digit number, it's likely an Indian PIN code
            // Map the first digit of PIN code to different regions of India for more accurate visualization
            const firstDigit = parseInt(location[0]);
            switch(firstDigit) {
                case 1: // Delhi, North India
                    targetCoords = "28.7041° N, 77.1025° E";
                    break;
                case 2: // Kolkata, East India
                    targetCoords = "22.5726° N, 88.3639° E";
                    break;
                case 3: // Mumbai, West India
                    targetCoords = "19.0760° N, 72.8777° E";
                    break;
                case 4: // Chennai, South India
                    targetCoords = "13.0827° N, 80.2707° E";
                    break;
                case 5: // Hyderabad, Central India
                    targetCoords = "17.3850° N, 78.4867° E";
                    break;
                case 6: // Ahmedabad, Western India
                    targetCoords = "23.0225° N, 72.5714° E";
                    break;
                case 7: // Bengaluru, Southern India
                    targetCoords = "12.9716° N, 77.5946° E";
                    break;
                case 8: // Northeast India
                    targetCoords = "27.5330° N, 91.8083° E";
                    break;
                default: // Default to center of India if unknown
                    targetCoords = "20.5937° N, 78.9629° E";
            }
        } else {
            // For city names or any other input, use scientific format
            targetCoords = "CALCULATING EXACT COORDINATES...";
        }
        
        // Add precise coordinates immediately
        trackingCoords.textContent = targetCoords;
        addTrackingMessage(scientificMessages[0]);
        
        // Add rapid scientific measurements
        setTimeout(() => {
            // Add more precise coordinates for non-PIN code searches
            if (targetCoords === "CALCULATING EXACT COORDINATES...") {
                const lat = (Math.random() * 90 * (Math.random() > 0.5 ? 1 : -1)).toFixed(4);
                const lon = (Math.random() * 180 * (Math.random() > 0.5 ? 1 : -1)).toFixed(4);
                trackingCoords.textContent = `${lat}° ${lat >= 0 ? 'N' : 'S'}, ${lon}° ${lon >= 0 ? 'E' : 'W'}`;
            }
            
            signalStrength.textContent = "98.7%";
            addTrackingMessage(scientificMessages[1]);
            addTrackingMessage(scientificMessages[2]);
        }, 300);
        
        // Very quick updates to satellite status
        setTimeout(() => {
            satelliteStatus.textContent = 'ATMOSPHERIC DATA ACQUISITION';
            addTrackingMessage(scientificMessages[3]);
            addTrackingMessage(scientificMessages[4]);
        }, 700);
        
        // Final scientific measurements
        setTimeout(() => {
            addTrackingMessage(scientificMessages[5]);
            addTrackingMessage(scientificMessages[6]);
        }, 1100);
        
        // Update the progress bar
        const progressInterval = setInterval(() => {
            progress += incrementPerStep;
            
            if (progress >= 100) {
                progress = 100;
                clearInterval(progressInterval);
                
                // Final quick data processing step
                addTrackingMessage("// METEOROLOGICAL DATA ACQUISITION COMPLETE");
                
                // Fetch the actual weather data immediately
                setTimeout(() => {
                    const formData = new FormData(weatherForm);
                    satelliteOverlay.classList.add('hidden');
                    showLoading(true);
                    fetchWeatherData(formData);
                }, 300);
            }
            
            // Update UI
            trackingProgress.style.width = `${progress}%`;
            progressPercentage.textContent = `${Math.floor(progress)}%`;
            
        }, updateInterval);
    }
    
    // Helper function to add tracking messages to the log
    function addTrackingMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = 'message';
        messageElement.textContent = message;
        messageLog.appendChild(messageElement);
        
        // Auto-scroll to bottom
        messageLog.scrollTop = messageLog.scrollHeight;
    }
    
    // Reset tracking animation state
    function resetTrackingAnimation() {
        trackingProgress.style.width = '0%';
        progressPercentage.textContent = '0%';
        trackingCoords.textContent = '--';
        signalStrength.textContent = '--';
        satelliteStatus.textContent = 'ACQUIRING SIGNAL';
        
        // Clear message log except for the first 3 default messages
        while (messageLog.children.length > 3) {
            messageLog.removeChild(messageLog.lastChild);
        }
    }
    
    // Function to fetch weather data
    function fetchWeatherData(formData) {
        // Make request to backend
        fetch('/get_weather', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            showLoading(false);
            
            if (data.error) {
                showError(data.error);
            } else {
                displayWeatherData(data);
                
                // If city was found from coordinates, update the input field
                if (formData.has('lat') && !formData.has('city')) {
                    cityInput.value = data.location.name;
                }
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showLoading(false);
            showError('Failed to fetch weather data. Please try again.');
        });
    }

    // Helper functions
    function showLoading(show) {
        loadingIndicator.style.display = show ? 'block' : 'none';
    }

    function showError(message) {
        errorText.textContent = message;
        errorMessage.style.display = 'block';
    }

    function hideError() {
        errorMessage.style.display = 'none';
    }

    function hideResults() {
        weatherResults.style.display = 'none';
        weatherResults.classList.remove('fade-in');
    }

    function displayWeatherData(data) {
        // Populate weather data
        cityName.textContent = data.location.name;
        countryName.textContent = data.location.country;
        localTimeValue.textContent = formatLocalTime(data.location.localtime);
        weatherIcon.src = 'https:' + data.current.condition.icon;
        weatherIcon.alt = data.current.condition.text;
        weatherCondition.textContent = data.current.condition.text;
        temperature.textContent = data.current.temp_c;
        humidity.textContent = data.current.humidity;
        windSpeed.textContent = data.current.wind_kph;

        // Show results with animation
        weatherResults.classList.add('fade-in');
        weatherResults.style.display = 'block';
    }

    function formatLocalTime(dateTimeStr) {
        try {
            const date = new Date(dateTimeStr);
            return date.toLocaleString('en-US', {
                weekday: 'short',
                month: 'short', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        } catch (e) {
            console.error('Error formatting date:', e);
            return dateTimeStr; // Return original string if parsing fails
        }
    }
});
